<?php 
// 1. TURN ON OUTPUT BUFFERING (Crucial: Fixes silent "Headers already sent" redirect failures)
ob_start();

// 2. ENABLE ERROR REPORTING (Helps catch hidden issues. Remove when making site public)
ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();
include('../config/db.php'); 

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    if (empty($_POST['email']) || empty($_POST['password'])) {
        $error = "All fields are required";
    } else {

        $email = trim($_POST['email']);
        $password = $_POST['password'];

        if ($conn) {
            $stmt = $conn->prepare("SELECT id, password FROM users WHERE email = ?");

            if ($stmt) {
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result && $result->num_rows === 1) {
                    $user = $result->fetch_assoc();

                    // CRITICAL: This only works if your DB passwords were saved using password_hash()
                    if (password_verify($password, $user['password'])) {

                        session_regenerate_id(true);
                        $_SESSION['user_id'] = $user['id'];

                        // 3. THE REDIRECT PATH
                        // If login.php and dashboard.php are in the SAME folder, use this:
                        header("Location: dashboard.php");
                        
                        // If dashboard.php is ONE FOLDER UP, comment the line above and uncomment this:
                        // header("Location: ../dashboard.php");
                        
                        exit();

                    } else {
                        $error = "Invalid email or password";
                    }
                } else {
                    $error = "Invalid email or password";
                }

                $stmt->close();
            } else {
                // Added detailed error output to see if the query itself is failing
                $error = "Database query failed: " . $conn->error; 
            }
        } else {
            $error = "Database connection failed";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
        body {
            font-family: 'Inter', sans-serif;
            background: #f4f7fe;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
        }

        .login-box {
            background: #fff;
            padding: 40px;
            width: 90%;
            max-width: 360px;
            box-sizing: border-box;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
            text-align: center;
        }

        .login-box h2 {
            margin-bottom: 30px;
            color: #2b3674;
            font-size: 24px;
        }

        input {
            width: 100%;
            padding: 12px 15px;
            margin: 10px 0;
            border-radius: 8px;
            border: 1px solid #e0e5f2;
            box-sizing: border-box;
            outline: none;
            transition: 0.2s;
            font-family: inherit;
        }
        input:focus {
            border-color: #4318ff;
        }

        button {
            width: 100%;
            padding: 12px;
            background: #4318ff;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            margin-top: 20px;
            font-size: 16px;
            font-weight: 500;
            transition: 0.2s;
        }

        button:hover {
            background: #3311db;
        }

        .error {
            background: #ffe2e5;
            color: #e31a1a;
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .register-link {
            margin-top: 25px;
            font-size: 14px;
            color: #a3aed1;
        }

        .register-link a {
            text-decoration: none;
            color: #4318ff;
            font-weight: 600;
        }
    </style>
</head>
<body>

<div class="login-box">
    <h2>Login</h2>

    <?php if (!empty($error)): ?>
        <div class="error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="email" name="email" placeholder="Enter Email" required>
        <input type="password" name="password" placeholder="Enter Password" required>
        <button type="submit">Login</button>
    </form>

    <div class="register-link">
        Not registered? <a href="register.php">Create an account</a>
    </div>
</div>

</body>
</html>