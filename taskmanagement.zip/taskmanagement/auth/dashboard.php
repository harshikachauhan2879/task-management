<?php
session_start();
include('../config/db.php');
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Task Manager Pro</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<header>
    <h1>Task Board</h1>
    <div class="header-actions">
        <input type="text" id="searchInput" class="search-bar" placeholder="Search tasks..." onkeyup="filterTasks()">
        <button class="btn btn-primary" onclick="openModal()">+ Add New Task</button>
        <button class="btn" style="background:#ffe2e5; color:#e31a1a;" onclick="openDeletedModal()">🗑️ Trash</button>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
</header>

<div class="board-container">
    <div class="board">
        <div class="column">
            <div class="column-header"><h3>To Do</h3></div>
            <div class="task-list" id="todo"></div>
        </div>
        <div class="column">
            <div class="column-header"><h3>In Progress</h3></div>
            <div class="task-list" id="in_progress"></div>
        </div>
        <div class="column">
            <div class="column-header"><h3>Done</h3></div>
            <div class="task-list" id="done"></div>
        </div>
    </div>
</div>

<div id="taskModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2 id="modalTitle">Add Task</h2>
            <button class="close-modal" onclick="closeModal()">&times;</button>
        </div>
        <form id="taskForm">
            <input type="hidden" name="id" id="taskId">
            
            <div class="form-group"><label>Title</label><input class="form-control" name="title" id="title" required placeholder="E.g., Design homepage"></div>
            <div class="form-group"><label>Description</label><textarea class="form-control" name="description" id="description" placeholder="Add details..."></textarea></div>

            <div class="form-row">
                <div class="form-group">
                    <label>Priority</label>
                    <select class="form-control" name="priority" id="priority">
                        <option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option>
                    </select>
                </div>
                <div class="form-group"><label>Due Date</label><input class="form-control" type="date" name="due_date" id="due_date"></div>
            </div>

            <div class="form-group"><label>Category</label><input class="form-control" name="category" id="category" placeholder="E.g., Frontend"></div>

            <div class="form-group">
                <label>Checklist Items</label>
                <div id="modalSubtasksList"></div>
                <button type="button" class="btn" style="background: #e0e5f2; color: #2b3674; margin-top: 5px; padding: 8px 15px; font-size: 13px;" onclick="addModalSubtask()">+ Add Checklist Item</button>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Task</button>
            </div>
        </form>
    </div>
</div>

<div id="deletedModal" class="modal">
    <div class="modal-content" style="max-width: 600px;">
        <div class="modal-header">
            <h2>Deleted Tasks</h2>
            <button class="close-modal" onclick="closeDeletedModal()">&times;</button>
        </div>
        <div id="deletedTasksList" style="max-height: 400px; overflow-y: auto;">
            <!-- Deleted tasks load here -->
        </div>
    </div>
</div>

<script src="../assets/js/app.js"></script>
</body>
</html>