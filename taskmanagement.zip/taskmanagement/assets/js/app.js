document.addEventListener("DOMContentLoaded", loadTasks);

let dragged = null;
let allTasks = []; // Cache for filtering

function loadTasks() {
    fetch("../api/fetch_tasks.php")
    .then(r=>r.json())
    .then(tasks=>{
        allTasks = tasks;
        renderTasks(tasks);
    }).catch(err => console.error("Error loading tasks:", err));
}

function renderTasks(tasks) {
    document.getElementById("todo").innerHTML = "";
    document.getElementById("in_progress").innerHTML = "";
    document.getElementById("done").innerHTML = "";

    tasks.forEach(t=>{
        let d = document.createElement("div");
        d.className="task";
        d.draggable=true;
        d.dataset.id=t.id;

        let dateDisplay = t.due_date ? new Date(t.due_date).toLocaleDateString() : 'No date';
        let desc = t.description || 'No description';
        let category = t.category || 'General';

        let subtasksHtml = `<div class="subtasks-container" onmousedown="event.stopPropagation()">`;
        if (t.subtasks && t.subtasks.length > 0) {
            t.subtasks.forEach(st => {
                let checked = st.is_done == 1 ? "checked" : "";
                let strike = st.is_done == 1 ? "style='text-decoration: line-through; opacity: 0.6;'" : "";
                subtasksHtml += `
                    <div class="subtask-item">
                        <input type="checkbox" onchange="toggleSubtask(${st.id}, this.checked)" ${checked}>
                        <span ${strike}>${st.title}</span>
                    </div>
                `;
            });
        }
        subtasksHtml += `</div>`;

        d.innerHTML = `
            <div class="task-meta">
                <span class="badge priority-${t.priority.toLowerCase()}">${t.priority}</span>
                <span class="task-date">📅 ${dateDisplay}</span>
            </div>
            <div class="task-title">${t.title}</div>
            <div class="task-desc">${desc.substring(0, 60)}${desc.length > 60 ? '...' : ''}</div>
            ${subtasksHtml}
            <div class="task-meta">
                <span style="font-size:12px; color:#a3aed1; font-weight:500;">📁 ${category}</span>
            </div>
            <div class="task-actions">
                <button onclick="editTask(${t.id})">✏️ Edit</button>
                <button class="delete-btn" onclick="deleteTask(${t.id})">🗑️ Delete</button>
            </div>
        `;

        d.addEventListener("dragstart", ()=>{
            dragged=d;
            setTimeout(() => d.style.opacity = '0.5', 0);
        });
        
        d.addEventListener("dragend", ()=>{
            dragged=null;
            d.style.opacity = '1';
        });

        const targetColumn = document.getElementById(t.status) || document.getElementById("todo");
        targetColumn.appendChild(d);
    });
}

function filterTasks() {
    const query = document.getElementById('searchInput').value.toLowerCase();
    const filtered = allTasks.filter(t => 
        t.title.toLowerCase().includes(query) || 
        (t.description && t.description.toLowerCase().includes(query)) ||
        (t.category && t.category.toLowerCase().includes(query))
    );
    renderTasks(filtered);
}

document.querySelectorAll(".task-list").forEach(col=>{
    col.addEventListener("dragover", e=>{
        e.preventDefault();
        col.classList.add('drag-over');
    });
    
    col.addEventListener("dragleave", e=> col.classList.remove('drag-over'));

    col.addEventListener("drop", ()=>{
        col.classList.remove('drag-over');
        if(!dragged) return;
        
        col.appendChild(dragged); // Optimistic UI update
        fetch("../api/save_task.php", {
            method: "POST",
            headers: {"Content-Type": "application/x-www-form-urlencoded"},
            body: `id=${dragged.dataset.id}&status=${col.id}`
        }).then(loadTasks).catch(err => console.error(err));
    });
});

function openModal(){ 
    document.getElementById("taskForm").reset();
    document.getElementById("taskId").value = "";
    document.getElementById("modalSubtasksList").innerHTML = "";
    document.getElementById("modalTitle").innerText = "Add Task";
    document.getElementById("taskModal").style.display="block"; 
}
function closeModal(){ document.getElementById("taskModal").style.display="none"; }

document.getElementById("taskForm").addEventListener("submit", e=>{
    e.preventDefault();
    const formData = new FormData(e.target);
    const isEdit = formData.get("id") !== "";

    fetch("../api/save_task.php", {
        method:"POST",
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.error) {
            showToast(data.error, "error");
        } else {
            showToast(isEdit ? "Task updated successfully!" : "Task added successfully!", "success");
            closeModal(); 
            loadTasks(); 
        }
    })
    .catch(err => {
        console.error(err);
        showToast("An error occurred while saving.", "error");
    });
});

function editTask(id){
    let t=allTasks.find(x=>x.id==id);
    if(!t) return;
    document.getElementById("modalTitle").innerText = "Edit Task";
    document.getElementById("taskId").value=t.id;
    document.getElementById("title").value=t.title;
    document.getElementById("description").value=t.description || "";
    document.getElementById("priority").value=t.priority;
    if(t.due_date) document.getElementById("due_date").value=t.due_date.split(' ')[0];
    document.getElementById("category").value=t.category || "";
    
    const container = document.getElementById("modalSubtasksList");
    container.innerHTML = "";
    
    if (t.subtasks && t.subtasks.length > 0) {
        t.subtasks.forEach(st => {
            const div = document.createElement("div");
            div.style.display = "flex";
            div.style.gap = "10px";
            div.style.marginBottom = "8px";
            
            const hiddenInput = document.createElement("input");
            hiddenInput.type = "hidden";
            hiddenInput.name = "subtask_ids[]";
            hiddenInput.value = st.id;
            
            const textInput = document.createElement("input");
            textInput.type = "text";
            textInput.className = "form-control";
            textInput.name = `existing_subtasks[${st.id}]`;
            textInput.value = st.title;
            textInput.required = true;
            
            const delBtn = document.createElement("button");
            delBtn.type = "button";
            delBtn.className = "btn";
            delBtn.style.cssText = "background:#ffe2e5; color:#e31a1a; padding: 0 15px;";
            delBtn.innerHTML = "&times;";
            delBtn.onclick = function() { div.remove(); };
            
            div.appendChild(hiddenInput);
            div.appendChild(textInput);
            div.appendChild(delBtn);
            
            container.appendChild(div);
        });
    }

    document.getElementById("taskModal").style.display="block";
}

function addModalSubtask() {
    const container = document.getElementById("modalSubtasksList");
    const div = document.createElement("div");
    div.style.display = "flex";
    div.style.gap = "10px";
    div.style.marginBottom = "8px";
    div.innerHTML = `
        <input type="text" class="form-control" name="subtasks[]" placeholder="Checklist item title..." required>
        <button type="button" class="btn" style="background:#ffe2e5; color:#e31a1a; padding: 0 15px;" onclick="this.parentElement.remove()">&times;</button>
    `;
    container.appendChild(div);
}

function toggleSubtask(subtaskId, isDone) {
    fetch("../api/save_subtask.php", {
        method: "POST",
        headers: {"Content-Type": "application/x-www-form-urlencoded"},
        body: `action=toggle&subtask_id=${subtaskId}&is_done=${isDone ? 1 : 0}`
    }).then(r => r.json()).then(res => {
        if (res.success) loadTasks();
    });
}

function deleteTask(id){
    if(!confirm("Delete?")) return;
    fetch("../api/delete_task.php?id="+id).then(() => {
        showToast("Task deleted successfully!", "success");
        loadTasks();
    }).catch(err => {
        showToast("Error deleting task.", "error");
    });
}

function showToast(message, type = 'success') {
    let toast = document.getElementById("toast");
    if (!toast) {
        toast = document.createElement("div");
        toast.id = "toast";
        document.body.appendChild(toast);
    }
    toast.innerText = message;
    toast.className = `toast show ${type}`;
    setTimeout(() => { toast.className = toast.className.replace("show", ""); }, 3000);
}

function openDeletedModal() {
    document.getElementById("deletedModal").style.display = "block";
    loadDeletedTasks();
}

function closeDeletedModal() {
    document.getElementById("deletedModal").style.display = "none";
}

function loadDeletedTasks() {
    fetch("../api/fetch_deleted_tasks.php")
    .then(r => r.json())
    .then(tasks => {
        const container = document.getElementById("deletedTasksList");
        container.innerHTML = "";
        if(tasks.length === 0) {
            container.innerHTML = "<p style='text-align:center; color:#a3aed1; padding: 20px 0;'>No deleted tasks in trash.</p>";
            return;
        }
        tasks.forEach(t => {
            let div = document.createElement("div");
            div.className = "deleted-task-item";
            div.innerHTML = `
                <div class="deleted-task-title">${t.title}</div>
                <button class="restore-btn" onclick="restoreTask(${t.id})">♻️ Restore</button>
            `;
            container.appendChild(div);
        });
    });
}

function restoreTask(id) {
    fetch("../api/restore_task.php?id=" + id)
    .then(r => r.json())
    .then(res => {
        if(res.success) {
            showToast("Task restored successfully!", "success");
            loadDeletedTasks();
            loadTasks();
        } else {
            showToast("Error restoring task", "error");
        }
    });
}