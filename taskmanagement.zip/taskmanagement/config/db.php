<?php
$conn = new mysqli("localhost", "root", "", "task_manager");

if ($conn->connect_error) {
    die("DB Error");
}

// Automatically create tasks table if it doesn't exist
$conn->query("
    CREATE TABLE IF NOT EXISTS tasks (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        priority VARCHAR(50) DEFAULT 'medium',
        due_date DATE NULL,
        category VARCHAR(100),
        status VARCHAR(50) DEFAULT 'todo',
        is_deleted TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
");

// Automatically create subtasks table if it doesn't exist
$conn->query("
    CREATE TABLE IF NOT EXISTS subtasks (
        id INT AUTO_INCREMENT PRIMARY KEY,
        task_id INT NOT NULL,
        title VARCHAR(255) NOT NULL,
        is_done TINYINT(1) DEFAULT 0,
        FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
    )
");

// Add is_deleted column if missing from earlier versions
$checkCol = $conn->query("SHOW COLUMNS FROM tasks LIKE 'is_deleted'");
if ($checkCol && $checkCol->num_rows == 0) {
    $conn->query("ALTER TABLE tasks ADD COLUMN is_deleted TINYINT(1) DEFAULT 0");
}
?>