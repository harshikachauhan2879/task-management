<?php
session_start();
include('../config/db.php');

$stmt = $conn->prepare("SELECT * FROM tasks WHERE user_id=? AND is_deleted=0 ORDER BY id ASC");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();

$res = $stmt->get_result();
$data = [];

while($row = $res->fetch_assoc()) {
    $row['subtasks'] = []; // Default empty array
    $data[] = $row;
}

if (!empty($data)) {
    $task_ids = array_column($data, 'id');
    $ids_str = implode(',', $task_ids);
    $sub_res = $conn->query("SELECT * FROM subtasks WHERE task_id IN ($ids_str)");
    
    if ($sub_res) {
        while($row = $sub_res->fetch_assoc()) {
            foreach ($data as &$task) {
                if ($task['id'] == $row['task_id']) {
                    $task['subtasks'][] = $row;
                }
            }
        }
    }
}

echo json_encode($data);