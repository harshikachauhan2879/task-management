<?php
session_start();
include('../config/db.php');

// Soft delete the task instead of hard deleting
$stmt = $conn->prepare("UPDATE tasks SET is_deleted=1 WHERE id=? AND user_id=?");
$stmt->bind_param("ii", $_GET['id'], $_SESSION['user_id']);
$stmt->execute();