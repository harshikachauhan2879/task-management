<?php
session_start();
header('Content-Type: application/json');
include('../config/db.php');

if (!isset($_SESSION['user_id'])) {
    exit(json_encode(['error' => 'Not authenticated']));
}

$user = $_SESSION['user_id'];

$id = !empty($_POST['id']) ? $_POST['id'] : null;
$title = trim($_POST['title'] ?? '');
$desc = trim($_POST['description'] ?? '');
$priority = $_POST['priority'] ?? 'medium';
$due = !empty($_POST['due_date']) ? $_POST['due_date'] : null;
$cat = trim($_POST['category'] ?? '');
$status = $_POST['status'] ?? 'todo';

if ($id && empty($title) && isset($_POST['status'])) {
    // drag only
    $stmt = $conn->prepare("UPDATE tasks SET status=? WHERE id=? AND user_id=?");
    if ($stmt) $stmt->bind_param("sii", $status,$id,$user);
} elseif ($id) {
    if (empty($title)) {
        exit(json_encode(['error' => 'Title is required']));
    }
    $stmt = $conn->prepare("UPDATE tasks SET title=?,description=?,priority=?,due_date=?,category=? WHERE id=? AND user_id=?");
    if ($stmt) $stmt->bind_param("sssssii",$title,$desc,$priority,$due,$cat,$id,$user);
} else {
    if (empty($title)) {
        exit(json_encode(['error' => 'Title is required']));
    }
    $stmt = $conn->prepare("INSERT INTO tasks(user_id,title,description,priority,due_date,category,status) VALUES(?,?,?,?,?,?,?)");
    if ($stmt) $stmt->bind_param("issssss",$user,$title,$desc,$priority,$due,$cat,$status);
}

if (isset($stmt) && $stmt !== false && $stmt->execute()) {
    $task_id_for_subtasks = $id ? $id : $conn->insert_id;
    
    if ($task_id_for_subtasks) {
        // Handle updates and deletions of existing subtasks if editing
        if ($id) {
            $existing_in_db = [];
            $res = $conn->query("SELECT id FROM subtasks WHERE task_id = " . (int)$task_id_for_subtasks);
            if ($res) {
                while ($row = $res->fetch_assoc()) {
                    $existing_in_db[] = $row['id'];
                }
            }
            
            $submitted_ids = isset($_POST['subtask_ids']) ? $_POST['subtask_ids'] : [];
            
            // Delete removed subtasks
            $to_delete = array_diff($existing_in_db, $submitted_ids);
            if (!empty($to_delete)) {
                $ids_to_delete = implode(',', array_map('intval', $to_delete));
                $conn->query("DELETE FROM subtasks WHERE id IN ($ids_to_delete)");
            }
            
            // Update submitted existing subtasks
            if (isset($_POST['existing_subtasks']) && is_array($_POST['existing_subtasks'])) {
                $upd_stmt = $conn->prepare("UPDATE subtasks SET title = ? WHERE id = ? AND task_id = ?");
                if ($upd_stmt) {
                    foreach ($_POST['existing_subtasks'] as $st_id => $st_title) {
                        $st_title = trim($st_title);
                        $st_id = (int)$st_id;
                        if (!empty($st_title)) {
                            $upd_stmt->bind_param("sii", $st_title, $st_id, $task_id_for_subtasks);
                            $upd_stmt->execute();
                        }
                    }
                }
            }
        }

        // Handle newly added subtasks
        if (!empty($_POST['subtasks']) && is_array($_POST['subtasks'])) {
            $sub_stmt = $conn->prepare("INSERT INTO subtasks (task_id, title) VALUES (?, ?)");
            if ($sub_stmt) {
                foreach ($_POST['subtasks'] as $sub_title) {
                    $sub_title = trim($sub_title);
                    if (!empty($sub_title)) {
                        $sub_stmt->bind_param("is", $task_id_for_subtasks, $sub_title);
                        $sub_stmt->execute();
                    }
                }
            }
        }
    }

    echo json_encode(['success' => true]);
} else {
    echo json_encode(['error' => 'Database error: ' . $conn->error]);
}