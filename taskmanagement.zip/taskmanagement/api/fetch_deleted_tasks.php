<?php
session_start();
include('../config/db.php');

$stmt = $conn->prepare("SELECT * FROM tasks WHERE user_id=? AND is_deleted=1 ORDER BY id DESC");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();

$res = $stmt->get_result();
$data = [];
while($row = $res->fetch_assoc()) {
    $data[] = $row;
}
echo json_encode($data);
?>