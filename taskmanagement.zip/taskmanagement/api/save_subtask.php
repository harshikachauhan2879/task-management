<?php
session_start();
header('Content-Type: application/json');
include('../config/db.php');

if (!isset($_SESSION['user_id'])) {
    exit(json_encode(['error' => 'Not authenticated']));
}

$action = $_POST['action'] ?? '';

if ($action === 'add') {
    $task_id = (int)$_POST['task_id'];
    $title = trim($_POST['title'] ?? '');
    
    if (empty($title)) exit(json_encode(['error' => 'Pointer title is required']));

    // Ensure user owns the task
    $check = $conn->prepare("SELECT id FROM tasks WHERE id=? AND user_id=?");
    $check->bind_param("ii", $task_id, $_SESSION['user_id']);
    $check->execute();
    if ($check->get_result()->num_rows === 0) exit(json_encode(['error' => 'Task not found']));

    $stmt = $conn->prepare("INSERT INTO subtasks (task_id, title) VALUES (?, ?)");
    $stmt->bind_param("is", $task_id, $title);
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['error' => 'Failed to add pointer']);
    }
} elseif ($action === 'toggle') {
    $subtask_id = (int)$_POST['subtask_id'];
    $is_done = (int)$_POST['is_done'];

    // Securely update via join to make sure the user owns the parent task
    $stmt = $conn->prepare("UPDATE subtasks JOIN tasks ON subtasks.task_id = tasks.id SET subtasks.is_done = ? WHERE subtasks.id = ? AND tasks.user_id = ?");
    $stmt->bind_param("iii", $is_done, $subtask_id, $_SESSION['user_id']);
    $stmt->execute();
    echo json_encode(['success' => true]);
}
?>