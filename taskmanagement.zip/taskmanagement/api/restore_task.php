<?php
session_start();
include('../config/db.php');

$stmt = $conn->prepare("UPDATE tasks SET is_deleted=0 WHERE id=? AND user_id=?");
$stmt->bind_param("ii", $_GET['id'], $_SESSION['user_id']);

if($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['error' => 'Failed to restore task']);
}
?>